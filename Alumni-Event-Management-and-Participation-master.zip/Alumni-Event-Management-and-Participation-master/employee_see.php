<html>

<head>

<html>
<head>
<title> Seu Attendence </title>
<link href="home.css" rel="stylesheet" type="text/css">
</head>
<body>
<header>
<video autoplay loop class="video-background" muted plays-inline>
<source src="videob.mp4" type="video/mp4">
</video>
<div class="nav">
<a href="home.html">
<img src="logo12.jpg" class="logo">
</a>

<ul class="menu">
<li> <a href="home.html">HOME</a></li> 
<li> <a href="employee_login.php">Logout</a></li>
<li> <a href="a">ABOUT</a></li>
</ul>


<div class="msg">
<h2>  Sucess To Login </h2>
<br>
<br>
<br>
<a href="studentinfo.html" class="btn input"> Update Student Info</a> 



</header>
</body>


</html>