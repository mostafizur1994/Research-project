<html>

<head>

<html>
<head>
<title> Seu Alumni Event Management </title>
<link href="home.css" rel="stylesheet" type="text/css">
</head>
<body>
<header>
<video autoplay loop class="video-background" muted plays-inline>
<source src="video.mp4" type="video/mp4">
</video>
<div class="nav">
<a href="home.html">
<img src="logo1.jpg" class="logo">
</a>

<ul class="menu">
<li> <a href="home.html">HOME</a></li> 
<li> <a href="admin_login.php">Logout</a></li>
<li> <a href="home.html">ABOUT</a></li>
</ul>


<div class="msg">
<h2>  Sucess To Login </h2>
<br>
<br>
<br>
<a href="admin_see.php" class="btn input"> Add Faculty</a> 
<a href="admin_see.php" class="btn input"> View Faculty</a> <br/> <br/> <br/> <br/> <br/>
<a href="admin_see.php" class="btn input"> Update Information</a> 
<a href="admin_see.php" class="btn input"> Delete Information</a> 



</header>
</body>


</html>