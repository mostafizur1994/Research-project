<html>

<head>

<html> 
<head>
<title> Seu Alumni Event Management </title>
<link href="alumni_sees.css" rel="stylesheet" type="text/css"> 
</head>
<body>
<header>
<video autoplay loop class="video-background" muted plays-inline>
<source src="video.mp4" type="video/mp4">
</video>
<div class="nav">
<a href="home.html">
<img src="logo1.jpg" class="logo">
</a>
 
<ul class="menu">
<li> <a href="home.html">HOME</a></li> 
<li> <a href="student_login.php">Logout</a></li>
<li> <a href="home.html">ABOUT</a></li>
</ul>


<div class="msg">
<h2>  </h2>
<br>
<br>
<br>
<a href="student_see.php" class="btn input"> Add Personal Informations</a>  <br/> <br/> <br/> <br/> <br/>
<a href="student_see.php" class="btn input"> Add Post</a> 
<a href="student_see.php" class="btn input"> Add Articles</a> <br/> <br/> <br/> <br/> <br/>
<a href="student_see.php" class="btn input"> Add Intern </a> 
<a href="student_see.php" class="btn input"> Intern Response </a>   <br/> <br/> <br/> <br/> <br/>
<a href="student_see.php" class="btn input"> View Article </a> 
<a href="student_see.php" class="btn input"> View Alumni Members </a> <br/> <br/> <br/> <br/> <br/>
<a href="student_see.php" class="btn input"> Job Post </a> 
<a href="student_see.php" class="btn input"> Event Post </a> 

</header>
</body>


</html>